<?php
    class Cliente{
        //Atributos
        private $id;
        private $nomeCliente;
        private $cpf;
        private $endereco;

        //Métodos de encapsulmento (getters e setters)
        public function getId(){
            return $this->id;
        }
        public function setId($id){
            $this->id = $id;
        }

        public function getNome(){
            return $this->nomeCliente;
        }
        public function setNome($nomeCliente){
            $this->nomeCliente = $nomeCliente;
        }

        public function getCpf(){
            return $this->cpf;
        }
        public function setCpf($cpf){
            $this->cpf = $cpf;
        }

        public function getEndereco(){
            return $this->endereco;
        }
        public function setEndereco($endereco){
            $this->endereco = $endereco;
        }
    }