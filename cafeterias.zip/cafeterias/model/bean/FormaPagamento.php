<?php 
    class FormaPagamento{
        //Atributos
        private $idFormaPagamento;
        private $nomePagamento;

        //Métodos de encapsulamento
        public function getIdFormaPagamento(){
            return $this->getIdFormaPagamento;
        }
        public function setIdFormaPagamento($idFormaPagamento){
            $this->idFormaPagamento = $idFormaPagamento;
        }

        public function getNomePagamento(){
            return $this->getnomePagamento;
        }
        public function setNomePagamento($nomePagamento){
            $this->nomePagamento = $nomePagamento;
        }
    }